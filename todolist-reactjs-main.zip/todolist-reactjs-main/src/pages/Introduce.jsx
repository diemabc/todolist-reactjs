import React from 'react';
import Information from '../componets/Information';

const Introduce = () => {
    return (
        <Information/>
    );
};

export default Introduce;