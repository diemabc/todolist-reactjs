import React from 'react';
import TodoList from '../componets/TodoList';
const ToDo = () => {
    return (       
        <TodoList/>
    );
};

export default ToDo;